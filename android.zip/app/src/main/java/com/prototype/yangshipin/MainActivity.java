package com.prototype.yangshipin;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.getcapacitor.BridgeActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 央视频直播原型（仅支持央视频）
 *
 * 还原桌面版「电视时光」对央视频的处理：
 * 1. WebView 直接加载央视频直播页（记忆上次 URL）
 * 2. onPageStarted 注入 window.api 桥（updateTvChannels / toggleMenu / returnToHome / saveChannelUrl）
 * 3. onPageFinished 注入插件 www/yangshipin.js（原样复用，未做修改）
 * 4. 插件扫描页面频道列表后经桥上报，原生侧用左侧渐变半透明面板作为频道菜单
 * 5. 菜单选台 → evaluateJavascript("jumpToChannel('频道名')") 回调注入
 */
public class MainActivity extends BridgeActivity {

    private static final String HOME_URL = "https://www.yangshipin.cn/tv/home?pid=600001859";
    private static final String SITE_PREFIX = "https://www.yangshipin.cn";
    private static final String PREFS_NAME = "ysp_proto";
    private static final String KEY_LAST_URL = "lastUrl";

    /** 提前注入的 window.api 桥，与桌面版 preload 提供的接口一致 */
    private static final String BRIDGE_JS =
        "(function(){if(window.__yspBridgeInstalled)return;window.__yspBridgeInstalled=true;" +
        "function call(m,p){try{if(window.__yspNative&&typeof window.__yspNative[m]==='function'){" +
        "window.__yspNative[m](p==null?'':String(p));}}catch(e){console.error('native bridge error',e);}}" +
        "window.api={" +
        "updateTvChannels:function(d){try{call('updateTvChannels',JSON.stringify(d));}catch(e){console.error('updateTvChannels',e);}}," +
        "toggleMenu:function(){call('toggleMenu','');}," +
        "returnToHome:function(){call('returnToHome','');}," +
        "saveChannelUrl:function(u){call('saveChannelUrl',u==null?'':u);}};" +
        "console.log('window.api bridge ready');})();";

    private WebView webView;
    private SharedPreferences prefs;
    private String pluginJs;

    private final List<String> cctvList = new ArrayList<>();
    private final List<String> satList = new ArrayList<>();
    private String currentChannel = "";
    private View menuRoot;      // 节目单整层（全屏透明，挂在 Activity 视图树上）
    private LinearLayout menuBox; // 节目单内容容器

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        pluginJs = readAsset("public/yangshipin.js");

        // 电视端：播放时保持常亮
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = (WebView) bridge.getWebView();
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        // 2K/4K 电视：禁止系统字体缩放干扰，保证渲染清晰
        settings.setTextZoom(100);
        // 桌面 UA：与 Electron 一致，确保站点输出桌面版页面（插件依赖桌面版 DOM 结构）
        settings.setUserAgentString(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");

        webView.setBackgroundColor(Color.BLACK);
        webView.addJavascriptInterface(new NativeApi(), "__yspNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                view.evaluateJavascript(BRIDGE_JS, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pluginJs != null) {
                    view.evaluateJavascript(pluginJs, null);
                }
            }
        });

        String last = prefs.getString(KEY_LAST_URL, "");
        webView.loadUrl(last.startsWith(SITE_PREFIX) ? last : HOME_URL);
    }

    @Override
    public void onResume() {
        super.onResume();
        applyImmersive();
        // 从后台/菜单返回后重新应用视频全屏化，防止样式被站点重置
        if (webView != null) {
            webView.evaluateJavascript("if(window.__yspFullscreen)window.__yspFullscreen();", null);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersive();
        }
    }

    /** 沉浸式全屏：电视上隐藏一切系统栏 */
    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    /**
     * 遥控器按键分发：
     * - 菜单键 → 打开原生频道菜单
     * - 音量键 → 转为页面内视频音量（与指示器一致），不改动系统音量
     * - 其余按键（方向键/OK/数字/字母）交给 WebView → 插件 yangshipin.js 处理
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int code = event.getKeyCode();
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (code == KeyEvent.KEYCODE_MENU && event.getRepeatCount() == 0) {
                showChannelMenu();
                return true;
            }
            if (code == KeyEvent.KEYCODE_VOLUME_UP) {
                adjustPageVolume(0.05);
                return true;
            }
            if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {
                adjustPageVolume(-0.05);
                return true;
            }
            if (menuRoot != null) {
                // 菜单打开：Back 关闭节目单
                if (code == KeyEvent.KEYCODE_BACK) {
                    removeMenuPanel();
                    return true;
                }
                // 方向键/OK 交给系统焦点导航（条目间移动 + 选中换台），
                // 其余按键（数字/字母等）一律消费，避免误操作底层页面
                boolean navKey = code == KeyEvent.KEYCODE_DPAD_UP
                    || code == KeyEvent.KEYCODE_DPAD_DOWN
                    || code == KeyEvent.KEYCODE_DPAD_LEFT
                    || code == KeyEvent.KEYCODE_DPAD_RIGHT
                    || code == KeyEvent.KEYCODE_ENTER
                    || code == KeyEvent.KEYCODE_DPAD_CENTER;
                if (!navKey) return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void adjustPageVolume(double delta) {
        webView.evaluateJavascript(
            "if(window.__yspAdjustVolume)window.__yspAdjustVolume(" + delta + ");", null);
    }

    private String readAsset(String path) {
        try {
            InputStream is = getAssets().open(path);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) {
                bos.write(buf, 0, n);
            }
            is.close();
            return bos.toString("UTF-8");
        } catch (Exception e) {
            Toast.makeText(this, "plugin js missing: " + path, Toast.LENGTH_LONG).show();
            return null;
        }
    }

    /** 右侧全屏透明区域点击回调由布局处理，此处仅保留 dp 换算 */
    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** 与桌面版主进程一致：菜单选台后延迟 80ms 注入 jumpToChannel */
    private void jumpToChannel(final String name) {
        runOnUiThread(() -> new android.os.Handler().postDelayed(
            () -> webView.evaluateJavascript("jumpToChannel(" + JSONObject.quote(name) + ")", null), 80));
    }

    /**
     * 显示/隐藏左侧节目单。
     * 不用 Dialog：应用宝等安卓运行环境对多窗口支持不稳（Dialog 可能不显示），
     * 直接把整层视图挂到 Activity 视图树上，单窗口最可靠。
     */
    private void showChannelMenu() {
        if (menuRoot != null) {
            removeMenuPanel();
            return;
        }

        // 全屏透明容器，内容为左侧 20% 屏宽渐变面板（左不透明 → 右全透明）
        FrameLayout root = new FrameLayout(this);

        int panelWidth = getResources().getDisplayMetrics().widthPixels / 5;

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        box.setPadding(pad, dp(44), pad, dp(24));
        // 消费面板内部的点击，避免误触关闭
        box.setOnClickListener(v -> {});
        scroll.addView(box);

        // 当前频道大标题
        TextView title = new TextView(this);
        title.setText(currentChannel == null || currentChannel.isEmpty()
            ? "\u9009\u53f0" : currentChannel); // 选台
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTextColor(0xFFFFFFFF);
        title.setShadowLayer(dp(3), 0, dp(1), 0xFF000000);
        title.setPadding(dp(6), 0, 0, dp(6));
        box.addView(title);

        // 频道未同步时面板仍然打开，给出可见提示
        if (cctvList.isEmpty() && satList.isEmpty()) {
            TextView hint = new TextView(this);
            hint.setText("\u9891\u9053\u6b63\u5728\u52a0\u8f7d\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5"); // 频道正在加载，请稍后重试
            hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            hint.setTextColor(0x99FFFFFF);
            hint.setPadding(dp(6), dp(8), 0, 0);
            box.addView(hint);
        }

        addSection(box, "\u592e\u89c6\u9891\u9053", cctvList); // 央视频道
        addSection(box, "\u536b\u89c6\u9891\u9053", satList);  // 卫视频道

        // 从左 92% 不透明黑渐变到右全透明
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xEB000000, 0x88000000, 0x00000000});
        scroll.setBackground(bg);

        root.addView(scroll, new FrameLayout.LayoutParams(
            panelWidth, ViewGroup.LayoutParams.MATCH_PARENT));
        // 点击面板右侧的透明区域关闭菜单
        root.setOnClickListener(v -> removeMenuPanel());

        menuBox = box;
        menuRoot = root;
        addContentView(root, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 遥控器适配：焦点自动落在第一个频道条目
        scroll.post(this::focusFirstChannel);
    }

    private void focusFirstChannel() {
        if (menuBox == null) return;
        for (int i = 0; i < menuBox.getChildCount(); i++) {
            View child = menuBox.getChildAt(i);
            if (child.isFocusable()) {
                child.requestFocus();
                return;
            }
        }
    }

    private void removeMenuPanel() {
        if (menuRoot != null && menuRoot.getParent() instanceof ViewGroup) {
            ((ViewGroup) menuRoot.getParent()).removeView(menuRoot);
        }
        menuRoot = null;
        menuBox = null;
        if (webView != null) webView.requestFocus();
    }

    private void addSection(LinearLayout box, String title, List<String> channels) {
        if (channels.isEmpty()) return;
        TextView header = new TextView(this);
        header.setText(title);
        header.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        header.setTextColor(0x80FFFFFF);
        header.setPadding(dp(6), dp(16), 0, dp(6));
        box.addView(header);

        final GradientDrawable focusBg = new GradientDrawable();
        focusBg.setColor(0x404A90D9);
        focusBg.setCornerRadius(dp(8));

        for (final String name : channels) {
            final TextView item = new TextView(this);
            item.setText(name);
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            item.setTextColor(0xDDFFFFFF);
            item.setPadding(dp(10), dp(10), dp(10), dp(10));
            item.setFocusable(true);
            item.setFocusableInTouchMode(true);
            item.setOnFocusChangeListener((v, hasFocus) -> {
                item.setTextColor(hasFocus ? 0xFFFFFFFF : 0xDDFFFFFF);
                item.setBackground(hasFocus ? focusBg : null);
            });
            item.setOnClickListener(v -> {
                removeMenuPanel();
                jumpToChannel(name);
            });
            box.addView(item);
        }
    }

    /** 注入到页面的原生桥实现（对应桌面版主进程 IPC） */
    private class NativeApi {
        @JavascriptInterface
        public void updateTvChannels(String json) {
            // 静默更新（handleVideoPlay 每次 play/playing 都会上报，toast 会刷屏）
            parseChannels(json);
        }

        @JavascriptInterface
        public void toggleMenu() {
            runOnUiThread(() -> showChannelMenu());
        }

        @JavascriptInterface
        public void returnToHome() {
            runOnUiThread(() -> webView.loadUrl(HOME_URL));
        }

        @JavascriptInterface
        public void saveChannelUrl(String url) {
            if (url != null && url.startsWith(SITE_PREFIX)) {
                prefs.edit().putString(KEY_LAST_URL, url).apply();
            }
        }
    }

    /**
     * 解析插件上报数据 {currentChannel, 央视频道:[], 卫视频道:[]}
     * 不在 Java 里写中文字面量（避免编码问题）：按首元素内容区分 CCTV 组与卫视组
     */
    private void parseChannels(String json) {
        cctvList.clear();
        satList.clear();
        currentChannel = "";
        if (json == null || json.isEmpty()) return;
        try {
            JSONObject obj = new JSONObject(json);
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if ("currentChannel".equals(key)) {
                    currentChannel = obj.optString(key, "");
                    continue;
                }
                JSONArray arr = obj.optJSONArray(key);
                if (arr == null) continue;
                boolean isCctv = false;
                if (arr.length() > 0) {
                    String first = arr.optString(0, "");
                    isCctv = first.contains("CCTV") || first.contains("CGTN");
                }
                List<String> target = isCctv ? cctvList : satList;
                for (int i = 0; i < arr.length(); i++) {
                    String name = arr.optString(i, "");
                    if (!name.isEmpty()) target.add(name);
                }
            }
        } catch (Exception ignored) {
        }
    }
}
