// CCTV 插件内容脚本 - 基于原版，仅增加：隐私弹窗处理、加载兜底、菜单频道同步

// 存储频道列表和当前频道索引
let channelList = [];
let overlay = null; // 存储遮挡层引用
let volumeIndicator = null; // 存储音量指示器引用
let volumeTimer = null; // 存储音量指示器隐藏计时器

let overlayTimer = null; // 用于自动隐藏遮罩层的定时器
let digitBuffer = ''; // 数字选台缓冲（遥控器/键盘）
let digitTimer = null;
let digitIndicator = null; // 数字选台指示器
let currentVideo = null; // 当前绑定的 video（站点可能重建播放器，需重新接管）

// 本地存储
if (localStorage.getItem('lastVolume') === null) {
  localStorage.setItem('lastVolume', '0.6'); // 设置默认音量
}

// --- 创建并管理带加载动画的遮罩层 ---

// 注入CSS样式用于加载动画
function injectSpinnerStyles() {
  const styleId = 'cctv-spinner-styles';
  if (document.getElementById(styleId)) return;

  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    .cctv-spinner {
      position: absolute;
      top: 60%;
      left: 50%;
      width: 60px;
      height: 60px;
      margin: 0 0 0 -30px;
      border: 5px solid rgba(255, 255, 255, 0.2);
      border-top-color: #ffffff;
      border-radius: 50%;
      animation: cctv-spin 1s linear infinite;
    }

    .cctv-channel-name {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      color: white;
      font-size: 98px;
      font-weight: bold;
      text-align: center;
      width: 100%;
    }

    .cctv-volume-indicator {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background-color: rgba(0, 0, 0, 0.7);
      color: white;
      padding: 15px 30px;
      border-radius: 10px;
      font-size: 36px;
      font-weight: bold;
      z-index: 1000000;
      opacity: 0;
      transition: opacity 0.3s ease-in-out;
      pointer-events: none;
      white-space: nowrap;
    }

    .cctv-volume-indicator.visible {
      opacity: 1;
    }

    .cctv-digit-indicator {
      position: fixed;
      top: 40px;
      right: 40px;
      background-color: rgba(0, 0, 0, 0.7);
      color: white;
      padding: 12px 24px;
      border-radius: 10px;
      font-size: 32px;
      font-weight: bold;
      z-index: 1000000;
      display: none;
      white-space: nowrap;
    }

    .cctv-digit-indicator.visible {
      display: block;
    }

    @keyframes cctv-spin {
      to { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);
}

// 显示遮罩层和加载动画
function showOverlay(channelName = '') {
  if (!overlay) {
    injectSpinnerStyles();
    overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'black';
    overlay.style.zIndex = '999999';
    overlay.id = 'cctv-overlay';

    const spinner = document.createElement('div');
    spinner.className = 'cctv-spinner';
    overlay.appendChild(spinner);

    const nameDisplay = document.createElement('div');
    nameDisplay.className = 'cctv-channel-name';
    nameDisplay.id = 'cctv-channel-name-display';
    overlay.appendChild(nameDisplay);
  }

  const nameDisplay = document.getElementById('cctv-channel-name-display');
  if (nameDisplay) {
    nameDisplay.textContent = channelName;
  }

  if (!overlay.parentNode) {
    document.body.appendChild(overlay);
  }
  overlay.style.display = 'block';
  console.log(`显示加载遮罩层，目标频道: ${channelName || '无'}`);

  // 8秒后自动隐藏
  if (overlayTimer) clearTimeout(overlayTimer);
  overlayTimer = setTimeout(() => {
    hideOverlay();
    overlayTimer = null;
    console.log('加载遮罩层已自动隐藏（超时8秒）');
  }, 8000);
}

// 隐藏遮罩层（等视频有首帧再撤，避免露出 video 元素默认的播放图标）
function hideOverlay() {
  if (!overlay) return;
  const v = document.querySelector('video');
  // readyState < 2 = 还没有任何可渲染帧；此时保留黑遮罩，稍后重试
  if (v && !v.error && v.readyState < 2) {
    if (overlayTimer) clearTimeout(overlayTimer);
    overlayTimer = setTimeout(hideOverlay, 300);
    return;
  }
  overlay.style.display = 'none';
  console.log('隐藏加载遮罩层');
  if (overlayTimer) {
    clearTimeout(overlayTimer);
    overlayTimer = null;
  }
}

// 将视频全屏化
function fullscreenVideo() {
  const video = document.querySelector('video');
  if (!video) {
    console.log('未找到 video 元素');
    return false;
  }

  // 隐藏 body 的直接子元素中非视频祖先的元素
  for (const child of document.body.children) {
    if (!child.contains(video) && child.id !== 'cctv-overlay') {
      child.style.setProperty('display', 'none', 'important');
    }
  }

  // 将视频及其所有父元素的样式重置，确保它们可见且占满全屏
  let current = video;
  while (current && current !== document.body) {
    current.style.setProperty('position', 'static', 'important');
    current.style.setProperty('width', '100%', 'important');
    current.style.setProperty('height', '100%', 'important');
    current.style.setProperty('max-width', 'none', 'important');
    current.style.setProperty('max-height', 'none', 'important');
    current.style.setProperty('margin', '0', 'important');
    current.style.setProperty('padding', '0', 'important');
    current.style.setProperty('visibility', 'visible', 'important');
    current.style.setProperty('opacity', '1', 'important');
    current.style.setProperty('display', 'block', 'important');
    current = current.parentElement;
  }

  document.documentElement.style.setProperty('height', '100%', 'important');
  document.documentElement.style.setProperty('width', '100%', 'important');
  document.documentElement.style.setProperty('overflow', 'hidden', 'important');
  document.body.style.setProperty('height', '100%', 'important');
  document.body.style.setProperty('width', '100%', 'important');
  document.body.style.setProperty('margin', '0', 'important');
  document.body.style.setProperty('padding', '0', 'important');
  document.body.style.setProperty('overflow', 'hidden', 'important');

  video.style.setProperty('position', 'fixed', 'important');
  video.style.setProperty('top', '0', 'important');
  video.style.setProperty('left', '0', 'important');
  video.style.setProperty('z-index', '9999', 'important');

  // 视频无首帧时隐藏自身（浏览器默认会给空 video 画一个大播放图标）
  bindVideoEmptyState(video);

  console.log('已通过修改父元素样式将视频全屏化');
  return true;
}

// 视频空态隐藏：readyState < 2（无可渲染帧）时 opacity 0 + 黑背景，
// 有帧后恢复。video 被页面重建后 fullscreenVideo 会重新调用并重新绑定。
function bindVideoEmptyState(v) {
  if (!v.__yspEmptyBound) {
    v.__yspEmptyBound = true;
    const show = () => v.style.setProperty('opacity', '1', 'important');
    const hide = () => {
      // 有 poster 的视频显示海报即可，不隐藏
      if (!v.poster && v.readyState < 2) {
        v.style.setProperty('opacity', '0', 'important');
      }
    };
    ['loadstart', 'emptied', 'waiting'].forEach(e => v.addEventListener(e, hide));
    ['loadeddata', 'canplay', 'playing'].forEach(e => v.addEventListener(e, show));
  }
  // 每次全屏化都会把 opacity 强制重置为 1（父链循环），
  // 因此无论是否已绑定，都按当前状态重新评估
  v.style.setProperty('background', '#000', 'important');
  if (!v.poster && v.readyState < 2) {
    v.style.setProperty('opacity', '0', 'important');
  }
}


// 模拟鼠标点击事件
function simulateClick(element) {
  const clickEvent = new MouseEvent('click', {
    bubbles: true,
    cancelable: true,
    view: window
  });
  element.dispatchEvent(clickEvent);
}

// 显示音量指示器
function showVolumeIndicator(volume) {
  if (!volumeIndicator) {
    volumeIndicator = document.createElement('div');
    volumeIndicator.className = 'cctv-volume-indicator';
    document.body.appendChild(volumeIndicator);
  }

  if (volumeTimer) {
    clearTimeout(volumeTimer);
  }

  if (volume === 0) {
    volumeIndicator.textContent = '静音';
  } else {
    volumeIndicator.textContent = `音量: ${Math.round(volume * 100)}`;
  }

  volumeIndicator.classList.add('visible');

  volumeTimer = setTimeout(() => {
    volumeIndicator.classList.remove('visible');
  }, 1500);
}

// 音量调整函数
function adjustVolume(delta) {
  const video = document.querySelector('video');
  if (video) {
    video.volume = Math.max(0, Math.min(1, video.volume + delta));
    console.log(`音量已调整为: ${video.volume.toFixed(2)}`);
    localStorage.setItem('lastVolume', String(video.volume));
    showVolumeIndicator(video.volume);
  }
}

// 播放/暂停切换（遥控器 OK 以外的媒体键、空格键、P 键）
function togglePlayPause() {
  const video = document.querySelector('video');
  if (!video) return;
  if (video.paused) {
    try {
      const p = video.play();
      if (p && p.catch) p.catch(() => {});
    } catch (e) {}
  } else {
    video.pause();
  }
}

// ==================== 数字选台（遥控器/键盘）====================

function showDigitIndicator() {
  if (!digitIndicator) {
    digitIndicator = document.createElement('div');
    digitIndicator.className = 'cctv-digit-indicator';
    document.body.appendChild(digitIndicator);
  }
  digitIndicator.textContent = '频道: ' + digitBuffer + '_';
  digitIndicator.classList.add('visible');
}

function hideDigitIndicator() {
  if (digitIndicator) digitIndicator.classList.remove('visible');
}

function commitDigits() {
  if (digitTimer) { clearTimeout(digitTimer); digitTimer = null; }
  const num = parseInt(digitBuffer, 10);
  digitBuffer = '';
  hideDigitIndicator();
  if (!num || channelList.length === 0) return;
  if (num >= 1 && num <= channelList.length) {
    const channel = channelList[num - 1];
    console.log(`数字选台: ${num} -> ${channel.name}`);
    showOverlay(channel.name);
    simulateClick(channel.element);
  }
}

function handleDigit(d) {
  digitBuffer += d;
  showDigitIndicator();
  if (digitBuffer.length >= 3) {
    commitDigits();
    return;
  }
  if (digitTimer) clearTimeout(digitTimer);
  digitTimer = setTimeout(commitDigits, 1200);
}

// ==================== 频道切换功能 ====================

// 设置频道切换功能
function setupChannelSwitching() {
  const channelParentDiv = findChannelParentDiv();
  if (!channelParentDiv) {
    console.log('未找到频道列表容器，1.5秒后重试');
    setTimeout(() => {
      const retry = findChannelParentDiv();
      if (retry) {
        channelList = getChannelList(retry);
        console.log(`重试成功，共找到 ${channelList.length} 个频道`);
        syncChannelsToMenu();
      }
    }, 1500);
    return;
  }

  channelList = getChannelList(channelParentDiv);
  console.log(`共找到 ${channelList.length} 个可用频道`);
  console.log('频道列表:', channelList.map(c => c.name));

  // 频道列表就绪后同步到主进程
  syncChannelsToMenu();

  updateKeyListener();
}

// 查找包含电视频道的父级div
function findChannelParentDiv() {
  const channelContainer = document.querySelector('.tv-main-con-r-list-left');
  if (channelContainer && channelContainer.children.length > 5) {
    console.log('通过类名 ".tv-main-con-r-list-left" 找到频道列表容器');
    return channelContainer;
  }

  console.log('直接定位失败或容器为空，尝试通过内容查找...');
  const channelKeywords = ['江苏卫视', '河南卫视', '北京卫视', 'CCTV13'];
  const channelElements = [];

  const allDivs = document.querySelectorAll('div[class*="oveerflow-1"]');
  allDivs.forEach(div => {
    const text = div.textContent.trim();
    if (channelKeywords.some(keyword => text.startsWith(keyword))) {
      channelElements.push(div);
    }
  });

  if (channelElements.length < 2) {
    console.log('未能找到足够的参考频道元素来确定公共父级');
    return null;
  }

  let parent = channelElements[0].parentElement;
  while (parent) {
    const isCommonParent = channelElements.every(elem => parent.contains(elem));
    if (isCommonParent) {
      console.log('通过查找共同父级找到频道列表容器:', parent);
      return parent;
    }
    parent = parent.parentElement;
  }

  console.log('未找到共同的频道列表容器');
  return null;
}

// 获取可用频道列表
function getChannelList(parentDiv) {
  const channels = [];
  const childDivs = parentDiv.children;

  for (let i = 0; i < childDivs.length; i++) {
    const div = childDivs[i];
    if (div.tagName.toLowerCase() !== 'div') continue;

    const textContent = div.textContent || '';

    if (textContent.includes('VIP')) {
      continue;
    }

    const channelName = extractChannelName(textContent);
    if (channelName) {
      channels.push({
        name: channelName,
        element: div
      });
    }
  }

  return channels;
}

// 从文本中提取频道名称
function extractChannelName(text) {
  return text.replace(/\([^)]*\)/g, '').trim();
}

// 切换到上一个频道
function switchToPreviousChannel() {
  if (channelList.length === 0) return;
  const currentIndex = channelList.findIndex(channel => channel.element.classList.contains('tvSelect'));
  if (currentIndex === -1) return;

  const prevIndex = (currentIndex - 1 + channelList.length) % channelList.length;
  const channel = channelList[prevIndex];

  console.log(`切换到上一个频道: ${channel.name}`);
  showOverlay(channel.name);
  simulateClick(channel.element);
}

// 切换到下一个频道
function switchToNextChannel() {
  if (channelList.length === 0) return;
  const currentIndex = channelList.findIndex(channel => channel.element.classList.contains('tvSelect'));
  if (currentIndex === -1) return;

  const nextIndex = (currentIndex + 1) % channelList.length;
  const channel = channelList[nextIndex];

  console.log(`切换到下一个频道: ${channel.name}`);
  showOverlay(channel.name);
  simulateClick(channel.element);
}

// 更新键盘监听
function updateKeyListener() {
  document.removeEventListener('keydown', handleKeyDown);
  document.addEventListener('keydown', handleKeyDown);
  console.log('已设置频道切换功能，按上下键可切换频道');
}


// 键盘事件处理（电视遥控器 + 物理键盘统一适配）
function isTypingTarget(el) {
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
}

function handleKeyDown(event) {
  // 键盘适配：输入框打字时所有按键交还给页面，不再拦截
  if (isTypingTarget(document.activeElement)) {
    if (event.key === 'Escape') document.activeElement.blur();
    return;
  }

  const key = event.key;
  console.log('我收到了按键事件:', key);

  // --- OK键/Enter/M：同步频道并打开菜单 ---
  if (key === 'Enter' || key === 'm' || key === 'M') {
    event.preventDefault();
    event.stopPropagation();
    if (window.api && typeof window.api.toggleMenu === 'function') {
      // 1. 获取最新的频道数据
      const channelData = NewChannels();

      // 2. 通过 bridge 发送数据到主进程
      if (window.api.updateTvChannels && typeof window.api.updateTvChannels === 'function') {
        console.log('发送最新频道数据到菜单:', channelData);
        window.api.updateTvChannels(channelData);
      }

      // 3. 请求打开菜单
      window.api.toggleMenu();
    } else {
      console.error('window.api.toggleMenu 不可用');
    }
    return;
  }

  switch (key) {
    // 上下：音量（遥控器 D-pad 上下 / 键盘方向键）
    case 'ArrowUp':
      event.preventDefault();
      event.stopImmediatePropagation();
      adjustVolume(0.05);
      break;
    case 'ArrowDown':
      event.preventDefault();
      event.stopImmediatePropagation();
      adjustVolume(-0.05);
      break;
    // 左右：换台；加减号仍是音量
    case 'ArrowRight':
      event.preventDefault();
      event.stopImmediatePropagation();
      switchToNextChannel();
      break;
    case 'ArrowLeft':
      event.preventDefault();
      event.stopImmediatePropagation();
      switchToPreviousChannel();
      break;
    case '=':
    case '+':
      event.preventDefault();
      event.stopImmediatePropagation();
      adjustVolume(0.05);
      break;
    case '-':
    case '_':
      event.preventDefault();
      event.stopImmediatePropagation();
      adjustVolume(-0.05);
      break;
    // 空格 / P / 媒体键：播放暂停、上下台
    case ' ':
    case 'p':
    case 'P':
    case 'MediaPlayPause':
      event.preventDefault();
      togglePlayPause();
      break;
    case 'MediaTrackNext':
      event.preventDefault();
      switchToNextChannel();
      break;
    case 'MediaTrackPrevious':
      event.preventDefault();
      switchToPreviousChannel();
      break;
    // H / Esc：回主页
    case 'h':
    case 'H':
    case 'Escape':
      event.preventDefault();
      if (window.api && typeof window.api.returnToHome === 'function') {
        window.api.returnToHome();
        console.log('已调用 returnToHome');
      } else {
        console.error('window.api.returnToHome 不可用');
      }
      break;
    default:
      // 数字键：直接选台（1.2 秒输入窗口）
      if (/^[0-9]$/.test(key)) {
        event.preventDefault();
        handleDigit(key);
      }
      break;
  }
}

// 获取最新的频道列表并分类
function NewChannels(channels) {
  channels = channelList;
  const categorizedChannels = {
    "currentChannel": "CCTV-1",
    "央视频道": [],
    "卫视频道": []
  };

  // 获取当前选中的频道元素
  const currentChannelElement = document.querySelector('div.tvSelect span');
  if (currentChannelElement) {
    let currentChannelName = '';
    for (const node of currentChannelElement.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) {
        currentChannelName = node.textContent.trim();
        break;
      }
    }
    if (currentChannelName) {
      console.log('@@@@@当前频道:', currentChannelName);
      categorizedChannels.currentChannel = currentChannelName;
    }
  }

  channels.forEach(channel => {
    const name = channel.name;
    if (name.includes('CCTV') || name.includes('CGTN')) {
      categorizedChannels.央视频道.push(name);
    } else {
      categorizedChannels.卫视频道.push(name);
    }
  });

  console.log('分类后的频道列表:', categorizedChannels);

  return categorizedChannels;

}

// 跳转到指定频道
function jumpToChannel(channelName) {
  const channel = channelList.find(c => c.name === channelName);
  if (channel) {
    console.log(`跳转到频道: ${channel.name}`);
    showOverlay(channel.name);
    simulateClick(channel.element);
  } else {
    console.log(`未找到频道: ${channelName}`);
  }
}

// 发送频道数据到主进程 store，供菜单读取
function syncChannelsToMenu() {
  if (channelList.length === 0) return;
  const data = NewChannels();
  if (data && window.api && typeof window.api.updateTvChannels === 'function') {
    window.api.updateTvChannels(data);
    console.log('已同步频道数据至菜单');
  }
}

// ==================== 隐私弹窗自动处理（新增）====================
function dismissPrivacyPopup() {
  const agreeBtn = document.querySelector('.winE-policy-close-b');
  if (agreeBtn) {
    console.log('检测到隐私弹窗，自动点击「同意」');
    agreeBtn.click();
    // 同意后刷新页面，确保正常加载
    setTimeout(() => {
      location.reload();
    }, 500);
    return true;
  }
  return false;
}

// --- 1. 监听URL变化并保存 ---
function setupUrlChangeListener() {
  let lastUrl = window.location.href;
  setInterval(() => {
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      console.log('检测到URL变化:', currentUrl);
      if (window.api && typeof window.api.saveChannelUrl === 'function') {
        window.api.saveChannelUrl(currentUrl);
      }
    }
  }, 5000);
}





function cctv_plugin() {
  console.log('CCTV 插件已加载7.0 (TV适配)');

  // --- 新增：检查隐私弹窗 ---
  if (dismissPrivacyPopup()) return;

  // 立即显示遮罩层
  showOverlay();

  // --- 新增：加载兜底，20 秒还没找到 video → 刷新页面 ---
  const loadStartTime = Date.now();
  const loadFallback = setInterval(() => {
    if (Date.now() - loadStartTime > 20000) {
      const v = document.querySelector('video');
      if (!v) {
        console.warn('20秒未找到视频，刷新页面重试');
        clearInterval(loadFallback);
        location.reload();
      } else {
        // 找到视频了就停掉检查
        clearInterval(loadFallback);
      }
    }
  }, 2000);

  // 绑定 video：全屏化 + 音量恢复 + 自动播放 + play 监听
  function attachVideo(videoElem) {
    const isNew = currentVideo !== videoElem;
    currentVideo = videoElem;

    // 应用/恢复上次保存的音量
    const stored = parseFloat(localStorage.getItem('lastVolume'));
    const startVolume = isNaN(stored) ? 0.6 : stored;
    videoElem.volume = Math.max(0, Math.min(1, startVolume));

    fullscreenVideo();

    if (isNew) {
      videoElem.addEventListener('play', handleVideoPlay);
      videoElem.addEventListener('playing', handleVideoPlay);

      // 电视端自动播放兜底（WebView 已允许无手势播放）
      try {
        const p = videoElem.play();
        if (p && p.catch) p.catch(() => {});
      } catch (e) {}

      // 如果视频已经在播放状态（可能错过play事件）
      if (!videoElem.paused) {
        handleVideoPlay();
      }

      // 首次绑定时设置频道切换功能
      if (channelList.length === 0) {
        setupChannelSwitching();
      }
    }
  }

  // 视频开始播放后隐藏遮罩层并确保音量正确（每次换台都会触发）
  function handleVideoPlay() {
    const storedNow = parseFloat(localStorage.getItem('lastVolume'));
    if (!isNaN(storedNow) && currentVideo) {
      currentVideo.volume = Math.max(0, Math.min(1, storedNow));
    }
    hideOverlay();

    if (channelList.length === 0) {
      setupChannelSwitching();
    } else {
      // 换台后自动同步当前频道状态给菜单
      syncChannelsToMenu();
    }
  }

  // MutationObserver 防抖：站点可能动态创建/重建 video，每次都重新接管
  let observerTimer = null;
  const videoObserver = new MutationObserver(() => {
    if (observerTimer) return;
    observerTimer = setTimeout(() => {
      observerTimer = null;
      const videoElem = document.querySelector('video');
      if (videoElem) attachVideo(videoElem);
    }, 200);
  });
  videoObserver.observe(document.body, { childList: true, subtree: true });

  // 兜底看门狗：样式被站点重置 / video 被替换 / 遮罩未隐藏时自动修复
  // （解决"一直停留在网页不能全屏播放"：换源、切清晰度后播放器重建导致全屏样式丢失）
  setInterval(() => {
    const videoElem = document.querySelector('video');
    if (!videoElem) return;

    if (videoElem !== currentVideo) {
      attachVideo(videoElem);
    } else if (videoElem.style.position !== 'fixed') {
      console.warn('看门狗：视频全屏样式丢失，重新应用');
      fullscreenVideo();
    }

    if (overlay && overlay.style.display !== 'none'
        && !videoElem.paused && !videoElem.ended) {
      hideOverlay();
    }
  }, 3000);

  // --- 新增：右键菜单也同步频道数据 ---
  document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    console.log('鼠标右键被触发');
    syncChannelsToMenu();
    if (window.api && typeof window.api.toggleMenu === 'function') {
      console.log('调用 toggleMenu 打开菜单');
      window.api.toggleMenu();
    } else {
      console.error('window.api.toggleMenu 不可用');
    }
  });

  // --- 单击画面打开节目单（应用宝/触屏/鼠标环境无遥控器菜单键，需要可见入口）---
  // 全屏化后视频上仍有站点播放器的点击层 div（控制层/logo 层），
  // 点击实际落在这些 div 上而非 video，因此判定放宽为：
  // 只要不是交互元素（链接/按钮/输入框）且不在节目单面板内，就视为画面点击
  document.addEventListener('click', (event) => {
    if (!window.api || typeof window.api.toggleMenu !== 'function') return;
    // 放行脚本合成的点击（插件自身的 simulateClick 换台、站点内部模拟点击都依赖它）
    if (event.isTrusted === false) return;
    const t = event.target;
    if (!t || t.nodeType !== 1) return;
    // 模拟器节目单面板内的点击交给条目自身的 onclick
    if (t.closest && t.closest('#menu-panel')) return;
    // 模拟器调试卡片（仅模拟器页面存在）不触发
    if (t.closest && t.closest('.hud')) return;
    // 交互元素放行
    if (t.closest && t.closest('input, textarea, select, button, a, [role=button], [contenteditable]')) return;
    event.preventDefault();
    event.stopPropagation();
    syncChannelsToMenu();
    window.api.toggleMenu();
  }, true); // capture 阶段拦截，避免页面播放器先消费点击

  // 供原生层调用：返回前台时重新全屏化、调整页面内音量
  window.__yspFullscreen = fullscreenVideo;
  window.__yspAdjustVolume = adjustVolume;
  window.__yspTogglePlay = togglePlayPause;

  // 设置键盘监听
  updateKeyListener();
  // 监听URL变化并保存
  setupUrlChangeListener();

}

cctv_plugin();